# import pandas as pd
import geopandas as gpd
import folium
# import pyproj
# import numpy as np
# import ast
# import branca.colormap as cm
# import matplotlib.pyplot as plt
# from shapely.geometry import Polygon
from util_TPR_platform import sci_notation, TPR_filepath
import os
# from risk_tier_calculation import generate_risk_tier
# from population_calculation import generate_population_density

tolerance = 0
# basic info of subzones
path_population_density = TPR_filepath('./source_data/consolidated_data/population_density_{:.0e}.geojson'.format(tolerance))
if not os.path.isfile(path_population_density):
    print('file of population density not found \n\t{}'.format(path_population_density))
    exit(0)
    # generate_population_density(path_population_density_out=path_population_density, tolerance=tolerance)
gdf_population_density = gpd.read_file(path_population_density)
gdf_population_density['geometry'] = gdf_population_density['geometry']

gdf_subzone_base = gdf_population_density[['SUBZONE_N', 'geometry', 'Remark']]

index_no_pop = gdf_subzone_base['Remark'] == 'no_census'
subzone_list_base = [x.title() for x in gdf_subzone_base['SUBZONE_N'][~index_no_pop].to_list()]

bounds = gdf_subzone_base['geometry'][~index_no_pop].apply(lambda x: x.bounds)
subzone_bounds_base = gdf_subzone_base[['SUBZONE_N']][~index_no_pop]
subzone_bounds_base.insert(loc=len(subzone_bounds_base.columns), column='geometry', value=bounds)

def compute_gdf_riskTier(mass, height, rate_str):
    filename_merged_riskTier = TPR_filepath('./source_data/risk_tier_merged_{}_{}kg_{}m.geojson'.format(rate_str, mass, height))
    filename_verbose_riskTier = TPR_filepath('./source_data/verbose_data/risk_tier_merged_{}_{}kg_{}m.csv'.format(rate_str, mass, height))

    if not os.path.isfile(filename_merged_riskTier):
        print('file of merged riskTier not found \n\t{}'.format(filename_merged_riskTier))
        exit(0)
        # generate_risk_tier(mass, height, path_riskTier_out=filename_merged_riskTier, path_verbose_riskTier_out=filename_verbose_riskTier)
    gdf_riskTier = gpd.read_file(filename_merged_riskTier)

    return gdf_riskTier

# Custom Color Feature
def getcolor(feature, col_name='RiskTier'):
    if feature['properties'][col_name] == 'High':
            return 'red'
    elif feature['properties'][col_name] == 'Med':
            return 'yellow'
    elif feature['properties'][col_name] == 'Low':
            return 'green'
    else:
        return 'black'

# Folium for Google Maps
def folium_choro(lat,lon):

    coords = (lat, lon)

    m = folium.Map(
                zoom_start=10.5,
                height='85%',
                location=coords,
                control_scale=True,
                tiles=None,
                max_bounds = True,
    )

    folium.raster_layers.TileLayer(
        tiles='http://mt1.google.com/vt/lyrs=s&h1=p1Z&x={x}&y={y}&z={z}',
        name='Satellite',
        attr='Google Map',
        min_zoom=10
    ).add_to(m)

    folium.raster_layers.TileLayer(
                tiles='http://mt1.google.com/vt/lyrs=m&h1=p1Z&x={x}&y={y}&z={z}',
                name='Standard Roadmap',
                attr='Google Map',
                min_zoom =10
    ).add_to(m)

    folium.raster_layers.TileLayer(
                tiles='http://mt1.google.com/vt/lyrs=y&h1=p1Z&x={x}&y={y}&z={z}',
                name='Hybrid',
                attr='Google Map',
                min_zoom =10
    ).add_to(m)

    return m