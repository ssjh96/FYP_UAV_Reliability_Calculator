# Mapping Module of TPR Platform
This is a module of TPR (Third Party Risk) Platform.

The TPR Platform is an interactive GUI that allows the pilot to input the information of the planned flight, and view the risk tiers of every hour from the map. 

This module is extracted from the TPR Platform for the Final Year Project. It only keeps the feature of showing the subzones of Singapore on the map, and disables the rest features to be more focused and reduce the workload of reading the code.

## Important functions
- The map is created using `Folium` package. The code of creating the basic map (road map, satellite map from Google) is in function `folium_choro()` at `Subzone_FYP.py ln58`. 

- The code to create subzones on the map are mainly in the function `create_map()` at ln1063 of `TPR_Platform_mappingModule.py`(referred as main code file for the rest of this document). 

- A `QtWebEngine` widget is used to load is at ln 686 of main code file.