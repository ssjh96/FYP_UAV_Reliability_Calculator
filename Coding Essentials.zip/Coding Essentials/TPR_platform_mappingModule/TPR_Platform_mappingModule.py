import sys
import folium
import pandas as pd
import numpy as np
#import qdarkstyle
from Subzone_FYP import folium_choro, compute_gdf_riskTier, subzone_list_base, getcolor
# from risk_tier_calculation import hour2mapTimeIndex
from folium.plugins import Draw
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtGui as qtg
from PyQt5 import QtCore as qtc
from PyQt5 import QtWebEngineWidgets, QtWebEngineCore
from util_TPR_platform import sci_notation, TPR_filepath, data_UA_type, data_compacting
# from fatality_rate_calculation import calculate_risk, calculate_risk_others_old
import geopandas as gpd
# from shapely.geometry import Point
import time

## Font styles
font_QGroupBox = qtg.QFont()
font_QGroupBox.setPointSize(10)
font_QGroupBox.setBold(True)
font_QGroupBox.setWeight(75)

font_norm = qtg.QFont()
font_norm.setPointSize(10)
font_norm.setBold(False)
font_norm.setWeight(50)

font_value = qtg.QFont()
font_value.setPointSize(12)
font_value.setBold(True)
font_value.setWeight(75)

font_label_fatal = qtg.QFont()
font_label_fatal.setFamily("MS Shell Dlg 2")

font_slider = qtg.QFont()
font_slider.setPointSize(10)

# color_background1 = "background-color:rgb(245,234,193);"
color_background1 = "background-color:#f7f9f7;"
color_background2 = "background-color:#faf4d3;"
color_background3 = "background-color:#ffe76f;"
color_cell_white = qtg.QColor('#FFFFFF')
color_cell_selected = qtg.QColor('#0F82DC')

def QTtranslate(textStr, context="MainWindow"):
    return qtc.QCoreApplication.translate(context, textStr)

def QTsizePolicy(widget, policy=None):
    dict_policy = {
        'fixed': qtw.QSizePolicy.Fixed,
        'minimum': qtw.QSizePolicy.Minimum,
        'maximum': qtw.QSizePolicy.Maximum,
        'preferred': qtw.QSizePolicy.Preferred,
        'expanding': qtw.QSizePolicy.Expanding,
        'minimumexpanding': qtw.QSizePolicy.MinimumExpanding,
    }
    if policy is None:
        policy = [qtw.QSizePolicy.MinimumExpanding, qtw.QSizePolicy.MinimumExpanding]
    if isinstance(policy, str):
        policy = [policy, policy]
    qtPolicy = []
    for policy_str in policy[:2]:
        if policy_str.lower() in dict_policy.keys():
            qtPolicy.append(dict_policy[policy_str.lower()])
        else:
            print('Policy "{}" is not in policy list, MinimumExpanding is used.'.format(policy))
            qtPolicy.append(qtw.QSizePolicy.MinimumExpanding)

    sizePolicy = qtw.QSizePolicy(*qtPolicy)
    sizePolicy.setHorizontalStretch(0)
    sizePolicy.setVerticalStretch(0)
    sizePolicy.setHeightForWidth(widget.sizePolicy().hasHeightForWidth())
    return sizePolicy


# scheme handler to load large map to QtWebEngine
class MapSchemeHandler(QtWebEngineCore.QWebEngineUrlSchemeHandler):
    def __init__(self, map_html=None, server_address=None):
        super().__init__()

        self.map_html = map_html
        self.server_address = server_address

    def set_map_html(self, map_html):
        self.map_html = map_html

    def set_server_address(self, server_address):
        self.server_address = server_address

    def requestStarted(self, request):
        buf = qtc.QBuffer(parent=self)
        request.destroyed.connect(buf.deleteLater)
        buf.open(qtc.QIODevice.WriteOnly)
        self.map_html.save(buf, close_file=False)
        buf.seek(0)
        buf.close()
        request.reply(b"text/html", buf)
        return

# object to load large map to QtWebEngine
class MapApplication(qtc.QObject):
    scheme = b"tprmap"

    def __init__(self, parent=None):
        super().__init__(parent)
        scheme = QtWebEngineCore.QWebEngineUrlScheme(MapApplication.scheme)
        QtWebEngineCore.QWebEngineUrlScheme.registerScheme(scheme)
        # self.m_functions = dict()

    def set_handler(self, profile=None, map_html=None, server_address=None):
        if profile is None:
            profile = QtWebEngineWidgets.QWebEngineProfile.defaultProfile()
        handler = profile.urlSchemeHandler(MapApplication.scheme)
        if handler is not None:
            profile.removeUrlSchemeHandler(handler)

        self.m_handler = MapSchemeHandler(map_html, server_address)
        profile.installUrlSchemeHandler(MapApplication.scheme, self.m_handler)

    def create_url(self, useMap2D=True):
        if useMap2D:
            url = qtc.QUrl()
            url.setScheme(MapApplication.scheme.decode())
            url.setHost('tpr_2d_map')
        else:
            url = qtc.QUrl()
            url.setUrl(self.m_handler.server_address)
        return url

# styles of the subzone regions
style_dict_norm = {
    # 'stroke': False, # false on style_function will disable stroke in highlight_function
    'color': '#FFFFFF',
    'opacity': 0.5,
    'weight': 1,
    'fillColor': '#FFFFFF',
    'fillOpacity': 0,
}
style_dict_highlight = { # when mouse is on, it will be highlighted
    # 'stroke': False,
    'color': '#FFFFFF',
    'opacity': 1,
    'weight': 1,
    'fillColor': '#FFFFFF',
    'fillOpacity': 0,
}
style_dict_oper_region = {
    # 'stroke': False,
    'color': '#FFFFFF',
    'opacity': 1,
    'weight': 2,
    'fillColor': '#FFFFFF',
    'fillOpacity': 0,
}
style_dict_grid = {
    # 'stroke': False, # false on style_function will disable stroke in highlight_function
    'color': '#FFFFFF',
    'opacity': 0.5,
    'weight': 1,
    'fillColor': '#FFFFFF',
    'fillOpacity': 0,
}

# styles with dynamic fillColor (depends on the input risk tier)
def style_dict_norm_grid(col_name='RiskTier'):
    return lambda feature: {
    'color': '#FFFFFF',
    'opacity': 1, # 0.1
    'weight': 2,
    'fillColor': getcolor(feature, col_name),
    'fillOpacity': 0.3,
}
def style_dict_highlight_grid(col_name='RiskTier'):
    return lambda feature: {
    'color': '#FFFFFF',
    'opacity': 1,
    'weight': 2,
    'fillColor': getcolor(feature, col_name),
    'fillOpacity': 0.5,
}


## Main part - UI window
class Ui_MainWindow(qtw.QMainWindow):
    def __init__(self, *args, **kwargs):
        super(Ui_MainWindow, self).__init__(*args, **kwargs)
        """MainWindow constructor"""

        self.map_app = MapApplication()
        # a parameter for TPR platform (DO NOT remove), not related to FYP project
        self.server_address = 'http://http://10.100.45.180:8000/tower'

        # #  data for ploting on folium map
        self.table_columns = ['Latitude', 'Longtitude', 'Altitude', 'Remarks']
        self.colIndex_remarks = self.table_columns.index('Remarks')
        self.data_from_user = {
            'operational_area': gpd.GeoDataFrame([]),
            'waypoints': pd.DataFrame([], columns=self.table_columns)
        }
        # self.listener_btn_add_wp_click = False

        # map object
        # self.input_area_bound = []

        self.flight_drone_mass = -1
        self.flight_drone_height = -1
        self.generate_risk_tier_data(mass=1.6, height=60.96, useGroundFatRisk=True) # assign self.gdf_riskTier
        self.subzone_list = subzone_list_base
        # self.subzone_bounds = subzone_bounds_base

        self.df_UA_info = pd.read_csv('../source_data/UA_info.csv')
        self.df_UA_info = self.df_UA_info.sort_values(by=['UA Brand', 'UA Model']).reset_index(drop=True)

    def setupUi(self, MainWindow):
        debug_i = 0
        debug_i += 1
        print('debug', debug_i)
        # Main UI code goes here
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1294, 800)
        self.centralwidget = qtw.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.centralwidget.setStyleSheet(color_background2)

        MainWindow.setSizePolicy(QTsizePolicy(self, 'Fixed'))

        # Layout and Properties
        self.horizontalLayout = qtw.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setObjectName('horizontalLayout')
        self.vLayout_left = qtw.QVBoxLayout()
        self.vLayout_left.setSizeConstraint(qtw.QLayout.SetDefaultConstraint)
        self.vLayout_left.setObjectName("vLayout_left")
        self.vLayout_right = qtw.QVBoxLayout()
        self.vLayout_right.setSizeConstraint(qtw.QLayout.SetDefaultConstraint)
        self.vLayout_right.setObjectName("vLayout_right")

        self.horizontalLayout.addLayout(self.vLayout_left)
        self.horizontalLayout.addLayout(self.vLayout_right)

        self.vLayout_top_right = qtw.QVBoxLayout()
        self.vLayout_top_right.setSizeConstraint(qtw.QLayout.SetDefaultConstraint)
        self.vLayout_top_right.setObjectName("vLayout_top_right")

        self.vLayout_btm_right = qtw.QVBoxLayout()
        self.vLayout_btm_right.setSizeConstraint(qtw.QLayout.SetDefaultConstraint)
        self.vLayout_btm_right.setObjectName("vLayout_btm_right")

        self.vLayout_right.addLayout(self.vLayout_top_right)
        self.vLayout_right.addLayout(self.vLayout_btm_right)

        # UA Type
        self.gb_ua_type = qtw.QGroupBox(self.centralwidget)
        self.gb_ua_type.setSizePolicy(QTsizePolicy(self.gb_ua_type, 'Minimum'))
        self.gb_ua_type.setFont(font_QGroupBox)
        self.gb_ua_type.setObjectName("gb_ua_type")
        self.gb_ua_type.setStyleSheet(color_background1)

        self.gridLayout_ua_type_1 = qtw.QGridLayout(self.gb_ua_type)
        self.gridLayout_ua_type_1.setObjectName("gridLayout_ua_type_1")

        # UA Brand
        self.formLayout_ua_brand = qtw.QFormLayout()
        self.formLayout_ua_brand.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_ua_brand.setObjectName("formLayout_ua_brand")

        self.label_ua_brand = qtw.QLabel(self.gb_ua_type)
        self.label_ua_brand.setFont(font_norm)
        self.label_ua_brand.setObjectName("label_ua_brand")
        self.formLayout_ua_brand.setWidget(0, qtw.QFormLayout.LabelRole, self.label_ua_brand)

        self.cbox_ua_brand = qtw.QComboBox(self.gb_ua_type)
        self.cbox_ua_brand.setObjectName("cbox_ua_brand")
        self.cbox_ua_brand.setFont(font_norm)
        self.formLayout_ua_brand.setWidget(0, qtw.QFormLayout.FieldRole, self.cbox_ua_brand)

        self.gridLayout_ua_type_1.addLayout(self.formLayout_ua_brand, 0, 0, 1, 1)

        # Add Data to cbox_ua_brand
        self.dict_ua_type_data = data_UA_type(self.df_UA_info)

        self.cbox_ua_brand.addItem('Select UA Brand...')
        for brand in self.dict_ua_type_data.keys():
            model_and_regNo = self.dict_ua_type_data[brand]
            self.cbox_ua_brand.addItem(brand, model_and_regNo)

        # Disable first category item
        self.cbox_ua_brand.model().item(0).setEnabled(False)
        # Click cbox_ua_brand
        self.cbox_ua_brand.activated.connect(self.fn_ua_brand_selected)

        debug_i += 1
        print('debug', debug_i)
        # UA Model
        self.formLayout_ua_model = qtw.QFormLayout()
        self.formLayout_ua_model.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_ua_model.setObjectName("formLayout_ua_model")

        self.label_ua_model = qtw.QLabel(self.gb_ua_type)
        self.label_ua_model.setFont(font_norm)
        self.label_ua_model.setObjectName("label_ua_model")
        self.formLayout_ua_model.setWidget(0, qtw.QFormLayout.LabelRole, self.label_ua_model)

        self.cbox_ua_model = qtw.QComboBox(self.gb_ua_type)
        self.cbox_ua_model.setObjectName("cbox_ua_model")
        self.cbox_ua_model.setFont(font_norm)
        self.cbox_ua_model.addItem('Select UA Brand to load Models...')
        self.cbox_ua_model.model().item(0).setEnabled(False)
        self.formLayout_ua_model.setWidget(0, qtw.QFormLayout.FieldRole, self.cbox_ua_model)
        
        self.gridLayout_ua_type_1.addLayout(self.formLayout_ua_model, 0, 1, 1, 1)

        self.cbox_ua_model.activated.connect(self.fn_ua_model_selected)
        
        # UA Registration Num
        self.formLayout_ua_reg = qtw.QFormLayout()
        self.formLayout_ua_reg.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_ua_reg.setObjectName("formLayout_ua_reg")
        
        self.label_ua_reg = qtw.QLabel(self.gb_ua_type)
        self.label_ua_reg.setFont(font_norm)
        self.label_ua_reg.setObjectName("label_ua_reg")
        self.formLayout_ua_reg.setWidget(0, qtw.QFormLayout.LabelRole, self.label_ua_reg)

        self.cbox_ua_reg = qtw.QComboBox(self.gb_ua_type)
        self.cbox_ua_reg.setFont(font_norm)
        self.cbox_ua_reg.setObjectName("cbox_ua_reg")
        self.cbox_ua_reg.addItem('Select UA Brand and Model to load Registration Number...')
        self.cbox_ua_reg.model().item(0).setEnabled(False)
        self.formLayout_ua_reg.setWidget(0, qtw.QFormLayout.FieldRole, self.cbox_ua_reg)

        self.gridLayout_ua_type_1.addLayout(self.formLayout_ua_reg, 1, 0, 1, 2)

        self.vLayout_left.addWidget(self.gb_ua_type)


        debug_i += 1
        print('debug', debug_i)

        # TODO pop-up window for user to fill in drone information

        # Operation Info
        self.gb_oper_info = qtw.QGroupBox(self.centralwidget)
        self.gb_oper_info.setSizePolicy(QTsizePolicy(self.gb_oper_info, 'Minimum'))
        self.gb_oper_info.setFont(font_QGroupBox)
        self.gb_oper_info.setObjectName("gb_oper_info")
        self.gb_oper_info.setStyleSheet(color_background1)

        self.gridLayout_oper_info = qtw.QGridLayout(self.gb_oper_info)
        self.gridLayout_oper_info.setObjectName("gridLayout_oper_info")

        # Operation Date
        currentDateTime = qtc.QDateTime.currentDateTime()
        self.formLayout_oper_date = qtw.QFormLayout()
        self.formLayout_oper_date.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_oper_date.setObjectName("formLayout_oper_date")

        self.label_oper_date = qtw.QLabel(self.gb_oper_info)
        self.label_oper_date.setFont(font_norm)
        self.label_oper_date.setObjectName("label_oper_date")
        self.formLayout_oper_date.setWidget(0, qtw.QFormLayout.LabelRole, self.label_oper_date)

        self.qde_oper_date = qtw.QDateEdit(self.gb_oper_info)
        self.qde_oper_date.setObjectName("qde_oper_date")
        self.qde_oper_date.setFont(font_norm)
        self.formLayout_oper_date.setWidget(0, qtw.QFormLayout.FieldRole, self.qde_oper_date)
        self.qde_oper_date.setCalendarPopup(True)
        self.qde_oper_date.setDateTime(currentDateTime)

        self._today_button = qtw.QPushButton(self.tr("Today"))
        self._today_button.clicked.connect(self._update_today)
        today_icon = self.style().standardIcon(qtw.QStyle.SP_DialogYesButton)
        self._today_button.setIcon(today_icon)
        self.qde_oper_date.calendarWidget().layout().addWidget(self._today_button)

        self.gridLayout_oper_info.addLayout(self.formLayout_oper_date, 0, 0, 1, 1)

        # Operation Time
        self.hLayout_oper_time = qtw.QHBoxLayout()
        self.hLayout_oper_time.setObjectName('hLayout_oper_time')

        self.formLayout_oper_hour = qtw.QFormLayout()
        self.formLayout_oper_hour.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_oper_hour.setObjectName("formLayout_oper_hour")

        self.label_oper_hour = qtw.QLabel(self.gb_oper_info)
        self.label_oper_hour.setFont(font_norm)
        self.label_oper_hour.setObjectName("label_oper_hour")
        self.formLayout_oper_hour.setWidget(0, qtw.QFormLayout.LabelRole, self.label_oper_hour)

        self.sbox_oper_hour = qtw.QSpinBox(self.gb_oper_info)
        self.sbox_oper_hour.setFont(font_norm)
        self.sbox_oper_hour.setObjectName("sbox_oper_hour")
        self.sbox_oper_hour.setMinimum(0)
        self.sbox_oper_hour.setMaximum(23)
        self.sbox_oper_hour.setSingleStep(1)
        self.sbox_oper_hour.setValue(currentDateTime.time().hour())
        # self.sbox_oper_hour.textChanged.connect(self.fn_oper_timeChanged)
        self.formLayout_oper_hour.setWidget(0, qtw.QFormLayout.FieldRole, self.sbox_oper_hour)
        self.hLayout_oper_time.addLayout(self.formLayout_oper_hour)

        self.formLayout_oper_minute = qtw.QFormLayout()
        self.formLayout_oper_minute.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_oper_minute.setObjectName("formLayout_oper_minute")

        self.label_oper_minute = qtw.QLabel(self.gb_oper_info)
        self.label_oper_minute.setFont(font_norm)
        self.label_oper_minute.setObjectName('label_oper_minute')
        self.formLayout_oper_minute.setWidget(0, qtw.QFormLayout.LabelRole, self.label_oper_minute)

        self.sbox_oper_minute = qtw.QSpinBox(self.gb_oper_info)
        self.sbox_oper_minute.setFont(font_norm)
        self.sbox_oper_minute.setObjectName("sbox_oper_minute")
        self.sbox_oper_minute.setMinimum(0)
        self.sbox_oper_minute.setMaximum(59)
        self.sbox_oper_minute.setSingleStep(1)
        self.sbox_oper_minute.setValue(currentDateTime.time().minute())
        # self.sbox_oper_minute.textChanged.connect(self.fn_oper_timeChanged)
        self.formLayout_oper_minute.setWidget(0, qtw.QFormLayout.FieldRole, self.sbox_oper_minute)
        self.hLayout_oper_time.addLayout(self.formLayout_oper_minute)

        self.gridLayout_oper_info.addLayout(self.hLayout_oper_time, 0, 1, 1, 1)

        # Operation Location
        self.formLayout_oper_location = qtw.QFormLayout()
        self.formLayout_oper_location.setSizeConstraint(qtw.QLayout.SetDefaultConstraint)
        self.formLayout_oper_location.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_oper_location.setObjectName("formLayout_oper_location")

        self.label_oper_location = qtw.QLabel(self.gb_oper_info)
        self.label_oper_location.setSizePolicy(QTsizePolicy(self.label_oper_location, 'Preferred'))
        self.label_oper_location.setFont(font_norm)
        self.label_oper_location.setObjectName("label_oper_location")
        self.formLayout_oper_location.setWidget(0, qtw.QFormLayout.LabelRole, self.label_oper_location)

        self.tbox_oper_location = QLineEdit_TPR(self.gb_oper_info)
        self.tbox_oper_location.setSizePolicy(QTsizePolicy(self.tbox_oper_location, 'Preferred'))
        self.tbox_oper_location.setFont(font_norm)
        self.tbox_oper_location.setObjectName("tbox_oper_location")
        self.tbox_oper_location.setPlaceholderText("Select Subzone Location...")
        self.tbox_oper_location.setClearButtonEnabled(True)
        # self.tbox_oper_location.textChanged.connect(self.fn_input_location)

        self.formLayout_oper_location.setWidget(0, qtw.QFormLayout.FieldRole, self.tbox_oper_location)
        self.gridLayout_oper_info.addLayout(self.formLayout_oper_location, 1, 0, 1, 2)

        self.btn_impt_oper_area = qtw.QPushButton(self.gb_oper_info)
        self.btn_impt_oper_area.setFont(font_norm)
        self.btn_impt_oper_area.setObjectName("btn_impt_oper_area")
        # self.btn_impt_oper_area.clicked.connect(self.fn_impt_oper_area)
        self.gridLayout_oper_info.addWidget(self.btn_impt_oper_area, 2, 1, 1, 1)

        # Add Data for Subzone Location (ComboBox)
        # AutoPrediction by Subzone
        self.completer_location = qtw.QCompleter(self.subzone_list)
        self.completer_location.setCaseSensitivity(qtc.Qt.CaseInsensitive)
        self.completer_location.setFilterMode(qtc.Qt.MatchContains)
        self.tbox_oper_location.setCompleter(self.completer_location)

        self.vLayout_left.addWidget(self.gb_oper_info)


        debug_i += 1
        print('debug', debug_i)
        # Altitude Information
        self.gb_altitude_info = qtw.QGroupBox(self.centralwidget)
        self.gb_altitude_info.setSizePolicy(QTsizePolicy(self.gb_altitude_info, 'Minimum'))
        self.gb_altitude_info.setFont(font_QGroupBox)
        self.gb_altitude_info.setObjectName("altitude_info_groupbox")
        self.gb_altitude_info.setStyleSheet(color_background1)
        self.hLayout_altitude_info = qtw.QHBoxLayout(self.gb_altitude_info)
        self.hLayout_altitude_info.setObjectName("hLayout_altitude_info")

        self.label_altitude_info = qtw.QLabel(self.gb_altitude_info)
        self.label_altitude_info.setFont(font_norm)
        self.label_altitude_info.setObjectName("label_altitude_info")
        self.hLayout_altitude_info.addWidget(self.label_altitude_info)

        self.dsbox_altitude = qtw.QDoubleSpinBox(self.gb_altitude_info)
        self.dsbox_altitude.setFont(font_value)
        self.setObjectName('dsbox_altitude')
        self.dsbox_altitude.setDecimals(1)
        self.dsbox_altitude.setMinimum(0)
        self.dsbox_altitude.setMaximum(1000)
        self.dsbox_altitude.setSingleStep(10)
        self.dsbox_altitude.setValue(200.0)
        # self.flight_drone_height = 60.96 # in meter
        self.hLayout_altitude_info.addWidget(self.dsbox_altitude)

        self.label_altitude_unit = qtw.QLabel(self.gb_altitude_info)
        self.label_altitude_unit.setFont(font_norm)
        self.label_altitude_unit.setObjectName("label_altitude_unit")
        self.hLayout_altitude_info.addWidget(self.label_altitude_unit)

        self.vLayout_left.addWidget(self.gb_altitude_info)

        # Waypoints
        self.gb_waypoints = qtw.QGroupBox(self.centralwidget)
        self.gb_waypoints.setSizePolicy(QTsizePolicy(self.gb_waypoints, ['Minimum', 'MinimumExpanding']))
        self.gb_waypoints.setFont(font_QGroupBox)
        self.gb_waypoints.setObjectName("waypoints_groupbox")
        self.gb_waypoints.setStyleSheet(color_background1)
        self.hLayout_waypoints = qtw.QHBoxLayout(self.gb_waypoints)
        self.hLayout_waypoints.setObjectName("hLayout_waypoints")

        self.vLayout_waypoint_btn_data = qtw.QVBoxLayout()
        self.vLayout_waypoint_btn_data.setObjectName('vLayout_waypoint_btn_data')

        self.btn_import_wp = qtw.QPushButton(self.gb_waypoints)
        self.btn_import_wp.setFont(font_QGroupBox) # font_norm
        self.btn_import_wp.setObjectName("btn_import_wp")
        icon = self.style().standardIcon(qtw.QStyle.SP_DirOpenIcon)
        self.btn_import_wp.setIcon(icon)
        self.btn_import_wp.setToolTip('Import waypoints...')
        self.btn_import_wp.setSizePolicy(QTsizePolicy(self.btn_import_wp, 'fixed'))
        # self.btn_import_wp.clicked.connect(self.fn_import_wp)
        self.vLayout_waypoint_btn_data.addWidget(self.btn_import_wp)

        self.btn_export_wp = qtw.QPushButton(self.gb_waypoints)
        self.btn_export_wp.setFont(font_QGroupBox) # font_norm
        self.btn_export_wp.setObjectName("btn_export_wp")
        icon = self.style().standardIcon(qtw.QStyle.SP_DirLinkIcon)
        self.btn_export_wp.setIcon(icon)
        self.btn_export_wp.setToolTip('Export waypoints...')
        self.btn_export_wp.setSizePolicy(QTsizePolicy(self.btn_export_wp, 'fixed'))
        # self.btn_export_wp.clicked.connect(self.fn_export_wp)
        self.vLayout_waypoint_btn_data.addWidget(self.btn_export_wp)

        self.btn_click_on_map = qtw.QPushButton(self.gb_waypoints)
        self.btn_click_on_map.setFont(font_norm)
        self.btn_click_on_map.setObjectName('btn_impt_fm_map')
        icon_marker = qtg.QIcon(qtg.QPixmap(TPR_filepath('../icon/icon_marker.png')))
        self.btn_click_on_map.setIcon(icon_marker)
        self.btn_click_on_map.setToolTip('Add a waypoint by clicking on the map')
        # self.btn_click_on_map.clicked.connect(self.fn_click_on_map)
        self.btn_click_on_map.setSizePolicy(QTsizePolicy(self.btn_click_on_map, 'fixed'))
        self.vLayout_waypoint_btn_data.addWidget(self.btn_click_on_map)

        self.btn_test = qtw.QPushButton(self.gb_waypoints)
        self.btn_test.setFont(font_norm)
        self.btn_test.setObjectName('btn_test')
        icon_map = qtg.QIcon(qtg.QPixmap(TPR_filepath('../icon/icon_map.png')))
        self.btn_test.setIcon(icon_map)
        self.btn_test.setToolTip('__test__')
        # self.btn_test.clicked.connect(self.fn_test)
        self.btn_test.setSizePolicy(QTsizePolicy(self.btn_test, 'fixed'))
        self.vLayout_waypoint_btn_data.addWidget(self.btn_test)

        self.hLayout_waypoints.addLayout(self.vLayout_waypoint_btn_data)

        self.tab_waypoints = qtw.QTableWidget(self.gb_waypoints)
        self.tab_waypoints.setFont(font_norm)
        self.tab_waypoints.horizontalHeader().setFont(font_QGroupBox)
        self.tab_waypoints.horizontalHeader().setSectionResizeMode(qtw.QHeaderView.Stretch)
        self.generateEmptyTable(0)
        self.tab_waypoints.setSizePolicy(QTsizePolicy(self.tab_waypoints, ['Preferred', 'MinimumExpanding']))
        self.tab_waypoints.setObjectName("table_waypoints")
        self.hLayout_waypoints.addWidget(self.tab_waypoints)
        palette_tab = self.tab_waypoints.palette()
        palette_tab.setColor(qtg.QPalette.Inactive, qtg.QPalette.Highlight, color_cell_selected)
        self.tab_waypoints.setPalette(palette_tab)

        ## waypoints buttons
        self.vLayout_waypoint_btn_table = qtw.QVBoxLayout()
        self.vLayout_waypoint_btn_table.setObjectName('vLayout_waypoint_btn_table')

        self.btn_add = qtw.QPushButton(self.gb_waypoints)
        self.btn_add.setFont(font_QGroupBox)
        self.btn_add.setObjectName("btn_add")
        icon_add = qtg.QIcon(qtg.QPixmap(TPR_filepath('../icon/icon_add.png')))
        self.btn_add.setIcon(icon_add)
        self.btn_add.setToolTip('Add a waypoint below')
        self.btn_add.setSizePolicy(QTsizePolicy(self.btn_add, 'fixed'))
        # self.btn_add.clicked.connect(self.fn_table_add_row)
        self.vLayout_waypoint_btn_table.addWidget(self.btn_add)

        self.btn_delete = qtw.QPushButton(self.gb_waypoints)
        self.btn_delete.setFont(font_QGroupBox)
        self.btn_delete.setObjectName("btn_delete")
        icon_minus = qtg.QIcon(qtg.QPixmap(TPR_filepath('../icon/icons_minus.png')))
        self.btn_delete.setIcon(icon_minus)
        self.btn_delete.setToolTip('Delete the selected waypoint')
        self.btn_delete.setSizePolicy(QTsizePolicy(self.btn_delete, 'fixed'))
        # self.btn_delete.clicked.connect(self.fn_table_delete_row)
        self.vLayout_waypoint_btn_table.addWidget(self.btn_delete)

        self.btn_clear = qtw.QPushButton(self.gb_waypoints)
        self.btn_clear.setFont(font_norm)
        self.btn_clear.setObjectName("btn_clear")
        icon = self.style().standardIcon(qtw.QStyle.SP_DialogCancelButton)
        self.btn_clear.setIcon(icon)
        self.btn_clear.setToolTip('Clear')
        self.btn_clear.setSizePolicy(QTsizePolicy(self.btn_clear, 'fixed'))
        # self.btn_clear.clicked.connect(self.fn_table_clear)
        self.vLayout_waypoint_btn_table.addWidget(self.btn_clear)

        self.btn_plot = qtw.QPushButton(self.gb_waypoints)
        self.btn_plot.setFont(font_QGroupBox)
        self.btn_plot.setObjectName("btn_plot")
        self.btn_plot.setSizePolicy(QTsizePolicy(self.btn_plot, 'fixed'))
        icon = self.style().standardIcon(qtw.QStyle.SP_DialogOkButton)
        self.btn_plot.setIcon(icon)
        self.btn_plot.setToolTip('Plot waypoints')
        # self.btn_plot.clicked.connect(self.fn_plot)
        self.vLayout_waypoint_btn_table.addWidget(self.btn_plot)

        self.hLayout_waypoints.addLayout(self.vLayout_waypoint_btn_table)

        self.vLayout_left.addWidget(self.gb_waypoints)

        debug_i += 1
        print('debug', debug_i)

        # Risk Assessment
        self.gb_risk_assess = qtw.QGroupBox(self.centralwidget)
        self.gb_risk_assess.setSizePolicy(QTsizePolicy(self.gb_risk_assess, 'Minimum'))
        self.gb_risk_assess.setFont(font_QGroupBox)
        self.gb_risk_assess.setObjectName("gp_risk_assess")
        self.gb_risk_assess.setStyleSheet(color_background1)
        self.hLayout_risk_assess = qtw.QHBoxLayout(self.gb_risk_assess)
        self.hLayout_risk_assess.setObjectName("hLayout_risk_assess")

        self.formLayout_fatality = qtw.QFormLayout()
        self.formLayout_fatality.setFormAlignment(qtc.Qt.AlignLeading | qtc.Qt.AlignLeft | qtc.Qt.AlignVCenter)
        self.formLayout_fatality.setObjectName('formLayout_fatality')

        self.label_fatal_max = qtw.QLabel(self.gb_risk_assess)
        self.label_fatal_max.setSizePolicy(QTsizePolicy(self.label_fatal_max, 'Preferred'))
        self.label_fatal_max.setSizeIncrement(qtc.QSize(0, 0))
        self.label_fatal_max.setFont(font_label_fatal)
        self.label_fatal_max.setLayoutDirection(qtc.Qt.LeftToRight)
        self.label_fatal_max.setAlignment(qtc.Qt.AlignRight | qtc.Qt.AlignTrailing | qtc.Qt.AlignVCenter)
        self.label_fatal_max.setObjectName("label_fatal_max")
        self.formLayout_fatality.setWidget(0, qtw.QFormLayout.LabelRole, self.label_fatal_max)

        self.tBox_risk_value_max = qtw.QLineEdit(self.gb_risk_assess)
        self.tBox_risk_value_max.setSizePolicy(QTsizePolicy(self.tBox_risk_value_max, ['Preferred', 'Fixed']))
        self.tBox_risk_value_max.setAlignment(qtc.Qt.AlignCenter)
        self.tBox_risk_value_max.setObjectName("tBox_risk_value_max")
        self.tBox_risk_value_max.setReadOnly(True)
        self.tBox_risk_value_max.setFont(font_value)
        self.formLayout_fatality.setWidget(0, qtw.QFormLayout.FieldRole, self.tBox_risk_value_max)

        self.label_fatal_avg = qtw.QLabel(self.gb_risk_assess)
        self.label_fatal_avg.setSizePolicy(QTsizePolicy(self.label_fatal_avg, 'Preferred'))
        self.label_fatal_avg.setSizeIncrement(qtc.QSize(0, 0))
        self.label_fatal_avg.setFont(font_label_fatal)
        self.label_fatal_avg.setLayoutDirection(qtc.Qt.LeftToRight)
        self.label_fatal_avg.setAlignment(qtc.Qt.AlignRight | qtc.Qt.AlignTrailing | qtc.Qt.AlignVCenter)
        self.label_fatal_avg.setObjectName("label_fatal_avg")
        self.formLayout_fatality.setWidget(1, qtw.QFormLayout.LabelRole, self.label_fatal_avg)

        self.tBox_risk_value_avg = qtw.QLineEdit(self.gb_risk_assess)
        self.tBox_risk_value_avg.setSizePolicy(QTsizePolicy(self.tBox_risk_value_avg, ['Preferred', 'Fixed']))
        self.tBox_risk_value_avg.setAlignment(qtc.Qt.AlignCenter)
        self.tBox_risk_value_avg.setObjectName("tBox_risk_value_avg")
        self.tBox_risk_value_avg.setReadOnly(True)
        self.tBox_risk_value_avg.setFont(font_value)
        self.formLayout_fatality.setWidget(1, qtw.QFormLayout.FieldRole, self.tBox_risk_value_avg)

        self.hLayout_risk_assess.addLayout(self.formLayout_fatality)

        self.risk_eval_btn = qtw.QPushButton(self.gb_risk_assess)
        self.risk_eval_btn.setSizePolicy(QTsizePolicy(self.risk_eval_btn, ['Preferred', 'Fixed']))
        self.risk_eval_btn.setFont(font_QGroupBox)
        self.risk_eval_btn.setObjectName("risk_eval_btn")
        risk_icon = self.style().standardIcon(qtw.QStyle.SP_DialogApplyButton)
        self.risk_eval_btn.setIcon(risk_icon)
        self.hLayout_risk_assess.addWidget(self.risk_eval_btn)
        # self.risk_eval_btn.clicked.connect(self.lambda_fat)

        self.vLayout_left.addWidget(self.gb_risk_assess)

        # Operation Risk
        self.gb_operation_risk = qtw.QGroupBox(self.centralwidget)
        self.gb_operation_risk.setSizePolicy(QTsizePolicy(self.gb_operation_risk, 'MinimumExpanding'))
        self.gb_operation_risk.setFont(font_QGroupBox)
        self.gb_operation_risk.setObjectName("gb_operation_risk")
        self.gb_operation_risk.setStyleSheet(color_background1)
        self.vLayout_operation_risk = qtw.QVBoxLayout(self.gb_operation_risk)
        self.vLayout_operation_risk.setObjectName("vLayout_operation_risk")

        # Web Engine - Risk Map
        self.risk_map = QtWebEngineWidgets.QWebEngineView(self.gb_operation_risk)
        page = WebEnginePage(self)
        self.risk_map.setPage(page)
        # Signal to export and download polygon
        self.risk_map.page().profile().downloadRequested.connect(self.handle_downloadRequested)
        self.risk_map.setSizePolicy(QTsizePolicy(self.risk_map, 'MinimumExpanding'))
        self.risk_map.setObjectName("risk_map")
        self.vLayout_operation_risk.addWidget(self.risk_map)
        self.vLayout_top_right.addWidget(self.gb_operation_risk)

        debug_i += 1
        print('debug', debug_i)

        # Navigation buttons
        self.gb_navigation = qtw.QGroupBox(self.centralwidget)
        self.gb_navigation.setSizePolicy(QTsizePolicy(self.gb_navigation, 'Minimum'))
        self.gb_navigation.setFont(font_QGroupBox)
        self.gb_navigation.setObjectName("gb_navigation")
        self.gb_navigation.setStyleSheet(color_background1)

        self.hLayout_navigation_buttons = qtw.QHBoxLayout(self.gb_navigation)
        self.hLayout_navigation_buttons.setObjectName("hLayout_navigation_buttons")

        self.btn_back = qtw.QPushButton(self.gb_operation_risk)
        self.btn_back.setFont(font_norm)
        self.btn_back.setObjectName("btn_back")
        icon_back = self.style().standardIcon(qtw.QStyle.SP_ArrowBack)
        self.btn_back.setIcon(icon_back)
        self.hLayout_navigation_buttons.addWidget(self.btn_back)

        self.btn_next = qtw.QPushButton(self.gb_operation_risk)
        self.btn_next.setFont(font_norm)
        self.btn_next.setObjectName("btn_next")
        icon_next = self.style().standardIcon(qtw.QStyle.SP_ArrowForward)
        self.btn_next.setIcon(icon_next)
        self.hLayout_navigation_buttons.addWidget(self.btn_next)

        self.btn_exit = qtw.QPushButton(self.gb_operation_risk)
        self.btn_exit.setFont(font_norm)
        self.btn_exit.setObjectName("btn_exit")
        icon_exit = self.style().standardIcon(qtw.QStyle.SP_BrowserStop)
        self.btn_exit.setIcon(icon_exit)
        # self.btn_exit.clicked.connect(self.exit)
        self.hLayout_navigation_buttons.addWidget(self.btn_exit)

        self.vLayout_btm_right.addWidget(self.gb_navigation)

        debug_i += 1
        print('debug', debug_i)

        # Menubar
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = qtw.QMenuBar()
        self.setMenuBar(self.menubar)
        self.menubar.setGeometry(qtc.QRect(0, 0, 999, 21))
        self.menubar.setObjectName("menubar")

        self.menu_Find = qtw.QMenu(self.menubar)
        self.menu_Find.setObjectName("menu_Find")
        self.menu_Help = qtw.QMenu(self.menubar)
        self.menu_Help.setObjectName("menu_Help")
        MainWindow.setMenuBar(self.menubar)

        self.action_Import = qtw.QAction(MainWindow)
        self.action_Import.setObjectName("action_Import")
        # self.action_Import.triggered.connect(self.fn_menu_import)

        self.action_Export = qtw.QAction(MainWindow)
        self.action_Export.setObjectName("action_Export")
        # self.action_Export.triggered.connect(self.fn_menu_export)

        self.action_Save = qtw.QAction(MainWindow)
        self.action_Save.setObjectName("action_Save")
        # self.action_Save.triggered.connect(self.fn_save)

        self.action_Print = qtw.QAction(MainWindow)
        self.action_Print.setObjectName("action_Print")

        self.action_Exit = qtw.QAction(MainWindow)
        self.action_Exit.setObjectName("action_Exit")
        # self.action_Exit.triggered.connect(self.exit)

        self.action_Guide = qtw.QAction(MainWindow)
        self.action_Guide.setObjectName("action_Guide")

        debug_i += 1
        print('debug', debug_i)

        # Icons
        import_icon = self.style().standardIcon(qtw.QStyle.SP_DirOpenIcon)
        print('debug A1')
        export_icon = self.style().standardIcon(qtw.QStyle.SP_DirLinkIcon)
        print('debug A2')
        save_icon = self.style().standardIcon(qtw.QStyle.SP_DialogSaveButton)
        print('debug A3')
        guide_icon = self.style().standardIcon(qtw.QStyle.SP_MessageBoxInformation)
        print('debug A4')

        debug_i += 1
        print('debug', debug_i)

        self.action_Import.setIcon(import_icon)
        self.action_Export.setIcon(export_icon)
        self.action_Save.setIcon(save_icon)
        self.action_Guide.setIcon(guide_icon)

        self.menu_Find.addAction(self.action_Import)
        self.menu_Find.addAction(self.action_Export)
        self.menu_Find.addSeparator()
        self.menu_Find.addAction(self.action_Save)
        self.menu_Find.addSeparator()
        self.menu_Find.addAction(self.action_Print)
        self.menu_Find.addSeparator()
        self.menu_Find.addAction(self.action_Exit)
        self.menu_Help.addAction(self.action_Guide)
        self.menu_Help.addSeparator()
        self.menubar.addAction(self.menu_Find.menuAction())
        self.menubar.addAction(self.menu_Help.menuAction())

        debug_i += 1
        print('debug', debug_i)

        self.statusbar = qtw.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        self.statusbar.showMessage("Copyright, Air Traffic Management Research Institute, 2021, All Rights Reserved.")
        MainWindow.setStatusBar(self.statusbar)

        print('B1')
        self.retranslateUi(MainWindow)
        print('B2')
        qtc.QMetaObject.connectSlotsByName(MainWindow)
        print('B3')

        self.create_map()
        print('B4')

    # def create_map_thread(self):
    #     self.statusbar.showMessage(QTtranslate('Loading map, please wait ...'))
    #     self.last_thread_start_time = time.time()
    #
    #     # function to execute, show progress
    #     kwargs = {
    #         'self_gdf_riskTier_compact': self.gdf_riskTier_compact,
    #         'oper_location_text': self.tbox_oper_location.text(),
    #         'self_air_matrix': self.air_matrix,
    #         'oper_hour_value': self.sbox_oper_hour.value(),
    #         'oper_minute_value': self.sbox_oper_minute.value(),
    #         'self_gdf_riskTier': self.gdf_riskTier,
    #         'self_subzone_list': self.subzone_list,
    #         'self_input_area_bound': self.input_area_bound,
    #         'self_data_from_user': self.data_from_user,
    #         'start_time': self.last_thread_start_time,
    #     }
    #     worker_map = Worker(self.create_map_fn, **kwargs)
    #     worker_map.signals.result.connect(self.fn_thread_result)
    #     worker_map.signals.progress.connect(self.fn_thread_progress)
    #     worker_map.signals.finished.connect(self.fn_thread_complete)
    #
    #     # Execute
    #     self.threadpool.start(worker_map)

    # def create_map_fn(self, progress_callback,
    #                   self_gdf_riskTier_compact,
    #                   oper_location_text,
    #                   self_air_matrix,
    #                   oper_hour_value, oper_minute_value,
    #                   self_gdf_riskTier, self_subzone_list,
    #                   self_input_area_bound,
    #                   self_data_from_user,
    #                   start_time,
    #                   ):
    #
    #     thread_progress = {
    #         'step_no': 0,
    #         'numSteps': 4,
    #         'step_name': '',
    #         'start_time': start_time,
    #     }
    #
    #     time_start = time.time()
    #     self_m = folium_choro(1.352083, 103.819839)
    #     draw = Draw(
    #         filename='activity_region.geojson',
    #         edit_options={'poly': {'allowIntersection': False}})
    #     draw.add_to(self_m)
    #     thread_progress['step_no'] += 1
    #     thread_progress['step_name'] = 'Generating base map'
    #     progress_callback.emit(thread_progress)
    #
    #     time_start = time.time()
    #     zone_list = []
    #     fg_riskTier = folium.FeatureGroup(name='RiskTier', control=False)
    #     gdf_choro = self_gdf_riskTier_compact.copy()
    #     if oper_location_text:
    #         if oper_location_text not in zone_list:
    #             zone_list.append(oper_location_text.upper())
    #         gdf_grid = self_air_matrix.generate_2D_AirMatrix(zone_list, buffer_range=2)
    #         gdf_choro = gdf_choro.append(gdf_grid, ignore_index=True)
    #
    #         layer_grid = folium.features.GeoJson(
    #             gdf_grid,
    #             style_function=lambda x: style_dict_grid,
    #             highlight_function=lambda x: style_dict_grid,
    #             name='AirMatrix',
    #             control=False,
    #         )
    #     else:
    #         layer_grid = None
    #     choro_time = TPR_TimeSliderChoropleth(
    #         gdf_choro.to_json(), # default_handler=str
    #         styledict=compute_choropleth_styledict(gdf_choro),
    #         currentTime=(oper_hour_value, oper_minute_value),
    #         name='Risk Tier',
    #         control=False,
    #     )
    #     fg_riskTier.add_child(choro_time)
    #
    #     layer_tooltip = folium.features.GeoJson(
    #         self_gdf_riskTier,
    #         style_function=lambda x: style_dict_norm,
    #         highlight_function=lambda x: style_dict_highlight,
    #         tooltip=folium.features.GeoJsonTooltip(
    #             fields=['SUBZONE_N'],
    #             aliases=['Subzone Neighbourhood'],
    #             style=("background-color: white; color: #333333; font-family: arial; font-size: 12px; padding: 10px;")
    #         ),
    #         name='Tooltip',
    #         control=False,
    #     )
    #     fg_riskTier.add_child(layer_tooltip)
    #
    #     text_location = oper_location_text
    #     if text_location in self_subzone_list:
    #         gdf_region_oper = self_gdf_riskTier.loc[self_gdf_riskTier['SUBZONE_N'] == text_location.upper()]
    #         region_oper = folium.features.GeoJson(
    #             gdf_region_oper,
    #             style_function= lambda x: style_dict_oper_region,
    #             highlight_function=lambda x: style_dict_oper_region,
    #             tooltip=folium.features.GeoJsonTooltip(
    #                 fields=['SUBZONE_N'],
    #                 aliases=['Subzone Neighbourhood'],
    #                 style=(
    #                     "background-color: white; color: #333333; font-family: arial; font-size: 12px; padding: 10px;")
    #             ),
    #             name='Region operation',
    #             control=False,
    #         )
    #         fg_riskTier.add_child(region_oper)
    #     if layer_grid is not None:
    #         fg_riskTier.add_child(layer_grid)
    #     self_m.add_child(fg_riskTier)
    #     self_m.keep_in_front(fg_riskTier)
    #
    #     time_duration = time.time() - time_start
    #     # print(time_duration, 'sec in folium_choro')
    #     thread_progress['step_no'] += 1
    #     thread_progress['step_name'] = 'Generating risk tiers'
    #     progress_callback.emit(thread_progress)
    #
    #     map_bounds = self_input_area_bound.copy()
    #
    #     # # operational area
    #     time_start = time.time()
    #     if self_data_from_user['operational_area'].empty:
    #         pass
    #     else:
    #         fg_oper_area = folium.FeatureGroup(name='Operational Area')
    #         oper_area = folium.features.GeoJson(
    #             self_data_from_user['operational_area'].to_json(),
    #             style_function=lambda x: {'fillColor': 'orange'},
    #             # control=False,
    #             highlight_function=lambda x: {'fillColor': 'blue'},
    #             tooltip='operational area',
    #             name='Operational Area'
    #         )
    #
    #         fg_oper_area.add_child(oper_area)
    #         self_m.add_child(fg_oper_area)
    #
    #         # boundary
    #         for i, area in self_data_from_user['operational_area'].iterrows():
    #             bd = area['geometry'].bounds
    #             map_bounds.append([ [bd[1], bd[0]], [bd[3], bd[2]] ])
    #     time_duration = time.time() - time_start
    #     # print(time_duration, 'sec in oper area')
    #     thread_progress['step_no'] += 1
    #     thread_progress['step_name'] = 'Generating operational area'
    #     progress_callback.emit(thread_progress)
    #
    #     # waypoints
    #     time_start = time.time()
    #     if self_data_from_user['waypoints'].empty:
    #         pass
    #     else:
    #         fg_waypoints = folium.FeatureGroup(name="Waypoints")
    #         points = []
    #         err_str = ''
    #         for i, row in self_data_from_user['waypoints'].iterrows():
    #             i = int(i)
    #             if not in_range(row):
    #                 err_str = err_str + 'Waypoint {} not in range\n'.format(i+1)
    #                 continue
    #             tooltip_str = '{:d} {:s}'.format(i+1, row[3])
    #             points.append([i+1, Point(row[1], row[0]), tooltip_str])
    #         if err_str != '':
    #             msg = qtw.QMessageBox()
    #             msg.setIcon(qtw.QMessageBox.Critical)
    #             msg.setText(QTtranslate(err_str))
    #             msg.setWindowTitle('Error in waypoints')
    #             msg.setStandardButtons(qtw.QMessageBox.Ok)
    #             msg.exec_()
    #         if points:
    #             waypoints = pd.DataFrame(points, columns=['id', 'geometry', 'tooltip'])
    #             waypoints = gpd.GeoDataFrame(waypoints)
    #             waypoints.crs = "EPSG:4326" # DO NOT USE 3414 !!!
    #             tooltip_waypoints = folium.features.GeoJsonTooltip(
    #                 fields=['tooltip'],
    #                 aliases=['Point '],
    #             )
    #             waypoints_gjson = folium.features.GeoJson(
    #                 waypoints,
    #                 name="Waypoints",
    #                 tooltip=tooltip_waypoints,
    #                 popup='popup',
    #             )
    #             fg_waypoints.add_child(waypoints_gjson)
    #             self_m.add_child(fg_waypoints)
    #
    #             # boundary
    #             sw = self_data_from_user['waypoints'][['Latitude', 'Longtitude']].min().values.tolist()
    #             ne = self_data_from_user['waypoints'][['Latitude', 'Longtitude']].max().values.tolist()
    #             map_bounds.append([sw, ne])
    #     time_duration = time.time() - time_start
    #     # print(time_duration, 'sec in waypoints')
    #     thread_progress['step_no'] += 1
    #     thread_progress['step_name'] = 'Generating waypoints'
    #     progress_callback.emit(thread_progress)
    #
    #     thread_result = {
    #         'self_m': self_m,
    #         'map_bounds': map_bounds,
    #         'start_time': start_time,
    #     }
    #     return thread_result


    # def fn_thread_result(self, thread_result):
    #     if thread_result['start_time'] == self.last_thread_start_time:
    #         self.last_thread_start_time = 0 # reset
    #
    #         self.m = thread_result['self_m']
    #         map_bounds = thread_result['map_bounds']
    #
    #         # add javascript to map
    #         self.js_click_listener(self.m)
    #
    #         layer_control = folium.LayerControl(position='bottomleft')
    #         layer_control.add_to(self.m)
    #         if map_bounds:
    #             self.m.fit_bounds(map_bounds)
    #         time_start = time.time()
    #
    #         # # for large html file
    #         self.map_app.set_handler(map_html=self.m, server_address=self.server_address)
    #         self.risk_map.load(self.map_app.create_url(True))
    #         self.statusbar.showMessage(QTtranslate('Map loaded. '))

    # def fn_thread_progress(self, thread_progress):
    #     if thread_progress['start_time'] == self.last_thread_start_time:
    #         percent = thread_progress['step_no'] / thread_progress['numSteps'] * 100
    #         progress_str = 'Loading map, please wait ... ({:.0f}%) {:s}'.format(percent, thread_progress['step_name'])
    #         self.statusbar.showMessage(QTtranslate(progress_str))


    # def fn_thread_complete(self):
    #     pass

    def create_map(self):
        # base Singapore map from Google
        time_start = time.time()
        self.m = folium_choro(1.352083, 103.819839)
        draw = Draw(
            # export=True,
            filename='activity_region.geojson',
            edit_options={'poly': {'allowIntersection': False}})
        draw.add_to(self.m)

        # layer of subzones
        time_start = time.time()
        # zone_list = []
        fg_riskTier = folium.FeatureGroup(name='RiskTier', control=False)
        layer_tooltip = folium.features.GeoJson(
            self.gdf_riskTier,
            style_function=lambda x: style_dict_norm,
            highlight_function=lambda x: style_dict_highlight,
            tooltip=folium.features.GeoJsonTooltip(
                fields=['SUBZONE_N'],
                aliases=['Subzone Neighbourhood'],
                style=("background-color: white; color: #333333; font-family: arial; font-size: 12px; padding: 10px;")
            ),
            name='Tooltip',
            control=False,
        )
        fg_riskTier.add_child(layer_tooltip)

        # text_location = self.tbox_oper_location.text()
        # if text_location in self.subzone_list:
        #     gdf_region_oper = self.gdf_riskTier.loc[self.gdf_riskTier['SUBZONE_N'] == text_location.upper()]
        #     region_oper = folium.features.GeoJson(
        #         gdf_region_oper,
        #         style_function= lambda x: style_dict_oper_region,
        #         highlight_function=lambda x: style_dict_oper_region,
        #         tooltip=folium.features.GeoJsonTooltip(
        #             fields=['SUBZONE_N'],
        #             aliases=['Subzone Neighbourhood'],
        #             style=(
        #                 "background-color: white; color: #333333; font-family: arial; font-size: 12px; padding: 10px;")
        #         ),
        #         name='Region operation',
        #         control=False,
        #     )
        #     fg_riskTier.add_child(region_oper)
        # if layer_grid is not None:
        #     fg_riskTier.add_child(layer_grid)
        self.m.add_child(fg_riskTier)
        self.m.keep_in_front(fg_riskTier)

        time_duration = time.time() - time_start
        # print(time_duration, 'sec in folium_choro')


        layer_control = folium.LayerControl(position='bottomleft')
        layer_control.add_to(self.m)

        # load folium map to QtWebEngine
        time_start = time.time()

        # # # (slow method) save as a html file and load
        # tmp_file = qtc.QTemporaryFile("tmpHTML/MAP_XXXXXX.html", self)
        # if tmp_file.open():
        #     self.filepath_map = tmp_file.fileName()
        #     url = qtc.QUrl.fromLocalFile(self.filepath_map)
        #     self.m.save(self.filepath_map)
        #     self.risk_map.load(url)
        # else:
        #     print('cannot open tmp file {}'.format(self.filepath_map))
        # # url = qtc.QUrl.fromStringList(['http://127.0.0.1:5000/'])[0]
        # # time_duration = time.time() - time_start
        # # print(time_duration, 'sec in saving')
        # # print('\n')

        # # (fast method but only works for map with a small size) save in buffer
        # data = io.BytesIO()
        # self.m.save(data, close_file=False)
        # self.html_address = data.getvalue().decode()
        # self.risk_map.setHtml(data.getvalue().decode())

        # # fast method and works for large html file
        self.map_app.set_handler(map_html=self.m, server_address=self.server_address)
        self.risk_map.load(self.map_app.create_url(True))

    def generate_risk_tier_data(self, mass=None, height=None, useGroundFatRisk=True):
        if mass is None:
            mass = self.flight_drone_mass
        if height is None:
            height = self.flight_drone_height
        if useGroundFatRisk:
            rate_str = 'gndFatRisk'
        else:
            rate_str = 'uaFailRate'
        self.gdf_riskTier = compute_gdf_riskTier(mass, height, rate_str=rate_str)
        index_no_pop = self.gdf_riskTier['Remark'] == 'no_census'
        self.gdf_riskTier_compact = data_compacting(self.gdf_riskTier[~index_no_pop])

    # def handleConsoleMessage_waypoint(self, msg):
    #     if self.listener_btn_add_wp_click:
    #         self.msg_data = json.loads(msg)
    #         lat = self.msg_data['coordinates']['lat']
    #         lng = self.msg_data['coordinates']['lng']
    #
    #         # check whether the current row is empty
    #         if self.tab_waypoints.currentRow() == -1:
    #             self.fn_table_add_row()
    #             rowIndex = self.tab_waypoints.rowCount() - 1
    #         else:
    #             empty_row = True
    #             for j in range(self.tab_waypoints.columnCount() - 1):
    #                 if self.tab_waypoints.item(self.tab_waypoints.currentRow(), j).text() != '':
    #                     empty_row = False
    #                     break
    #             if empty_row:
    #                 rowIndex = self.tab_waypoints.currentRow()
    #             else:
    #                 self.fn_table_add_row()
    #                 rowIndex = self.tab_waypoints.currentRow() + 1
    #
    #         self.tab_waypoints.setItem(rowIndex, 0, qtw.QTableWidgetItem('{:.6f}'.format(lat)))
    #         self.tab_waypoints.setItem(rowIndex, 1, qtw.QTableWidgetItem('{:.6f}'.format(lng)))
    #         self.tab_waypoints.setItem(rowIndex, 2, qtw.QTableWidgetItem('{:.1f}'.format(self.dsbox_altitude.value())))
    #
    #         self.getDataFromQTable() # update data to self.data_from_user['waypoints']
    #
    #         self.fn_plot()
    #
    #         self.listener_btn_add_wp_click = False
    #         self.btn_click_on_map.setStyleSheet(color_background1)


    # def handleConsoleMessage_timeSlider(self, msg):
    #     msg_data = json.loads(msg)
    #     timeStr = msg_data['time']
    #     hour, minute = timeStr.split(':')
    #     hour = int(hour)
    #     # minute = int(minute) # TODO set time for minute
    #     self.timeChanged_trigger = False
    #     self.sbox_oper_hour.setValue(hour)
    #     # self.sbox_oper_minute.setValue(minute) # TODO set time for minute
    #     self.timeChanged_trigger = True

    # def js_click_listener(self, map_object):
    #     my_js = f"""{map_object.get_name()}.on("click",
    #              function (e) {{
    #                 var data = `{{"coordinates": ${{JSON.stringify(e.latlng)}}}}`;
    #                 console.log(data)}});"""
    #
    #     e = Element(my_js)
    #     html = map_object.get_root()
    #     html.script.get_root().render()
    #     # Insert new element or custom JS
    #     html.script._children[e.get_name()] = e



    # Titles
    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QTtranslate("Visual Line of Sight (VLOS) Module (Mapping Module)"))

        self.gb_ua_type.setTitle(QTtranslate("UA Type"))
        self.label_ua_brand.setText(QTtranslate("UA Brand"))
        self.label_ua_model.setText(QTtranslate("UA Model"))
        self.label_ua_reg.setText(QTtranslate("UA Registration No:"))

        self.gb_oper_info.setTitle(QTtranslate("Operation Information"))
        self.label_oper_date.setText(QTtranslate("Date"))
        self.label_oper_hour.setText(QTtranslate("Time"))
        self.label_oper_minute.setText(QTtranslate(":"))
        self.label_oper_location.setText(QTtranslate("Location (Subzone)"))
        self.btn_impt_oper_area.setText(QTtranslate("Import operational area..."))

        self.gb_altitude_info.setTitle(QTtranslate("Altitude Information"))
        self.label_altitude_info.setText(QTtranslate("Max Altitude Allowed: "))
        self.label_altitude_unit.setText(QTtranslate("feet"))

        self.gb_waypoints.setTitle(QTtranslate("Waypoints"))

        self.gb_risk_assess.setTitle(QTtranslate("Risk Assessment (Fatality Rate)"))
        self.risk_eval_btn.setText(QTtranslate("Evaluate"))
        self.label_fatal_max.setText(QTtranslate("Ground Fatality Rate (Maximum)"))
        self.label_fatal_avg.setText(QTtranslate("Ground Fatality Rate (Average)"))
        self.gb_operation_risk.setTitle(QTtranslate("Map"))
        self.btn_back.setText(QTtranslate("Back"))
        self.btn_next.setText(QTtranslate("Next"))
        self.btn_exit.setText(QTtranslate("Exit"))
        self.menu_Find.setTitle(QTtranslate("&Find"))
        self.menu_Help.setTitle(QTtranslate("&Help"))
        self.action_Import.setText(QTtranslate("&Import"))
        self.action_Export.setText(QTtranslate("&Export"))
        self.action_Save.setText(QTtranslate("&Save"))
        self.action_Print.setText(QTtranslate("&Print"))
        self.action_Exit.setText(QTtranslate("&Exit"))
        self.action_Guide.setText(QTtranslate("&Guide"))

    def exit(self):
        # pop up goodBye dialog
        self.destroy(VLOSWindow)

        # End main UI code
        # self.show()

    # def fn_table_add_row(self):
    #     if self.tab_waypoints.currentRow() == -1:
    #         newIndex = self.tab_waypoints.rowCount()
    #     else:
    #         newIndex = self.tab_waypoints.currentRow() + 1
    #     self.tab_waypoints.insertRow( newIndex )
    #
    #     numRows = self.tab_waypoints.rowCount()
    #     numCols = self.tab_waypoints.columnCount()
    #
    #     # update text in cells
    #     for j in range(numCols):
    #         self.tab_waypoints.setItem(newIndex, j, qtw.QTableWidgetItem())
    #     if newIndex == 0:
    #         self.tab_waypoints.item(newIndex, self.colIndex_remarks).setText('Take-off')
    #         if numRows >= 3:
    #             self.tab_waypoints.item(newIndex+1, self.colIndex_remarks).setText('Waypoint')
    #         elif numRows == 2:
    #             self.tab_waypoints.item(newIndex+1, self.colIndex_remarks).setText('Landing')
    #     elif newIndex == numRows - 1:
    #         self.tab_waypoints.item(newIndex, self.colIndex_remarks).setText('Landing')
    #         if numRows >= 3:
    #             self.tab_waypoints.item(newIndex-1, self.colIndex_remarks).setText('Waypoint')
    #     else:
    #         self.tab_waypoints.item(newIndex, self.colIndex_remarks).setText('Waypoint')
    #     self.tab_waypoints.setCurrentCell(self.tab_waypoints.currentRow(), self.tab_waypoints.currentColumn())

    # def fn_table_delete_row(self):
    #     if self.tab_waypoints.rowCount() < 1:
    #         return
    #
    #     if self.tab_waypoints.currentRow() < 0:
    #         rowIndex = self.tab_waypoints.rowCount() - 1 # index of the last row
    #     else:
    #         rowIndex = self.tab_waypoints.currentRow()
    #     self.tab_waypoints.removeRow(rowIndex)
    #
    #     numRows = self.tab_waypoints.rowCount()
    #     if rowIndex == 0:
    #         self.tab_waypoints.setItem(0, self.colIndex_remarks, qtw.QTableWidgetItem('Take-off'))
    #     elif rowIndex == numRows:
    #         if numRows >= 2:
    #             self.tab_waypoints.setItem(numRows-1, self.colIndex_remarks, qtw.QTableWidgetItem('Landing'))
    #     self.tab_waypoints.setCurrentCell(self.tab_waypoints.currentRow(), self.tab_waypoints.currentColumn())

    # def fn_table_clear(self):
    #     # operational area
    #     self.data_from_user['operational_area'] = gpd.GeoDataFrame([])
    #     # waypoints
    #     self.tab_waypoints.clear()
    #     self.data_from_user['waypoints'] = pd.DataFrame([], columns=self.table_columns)
    #     self.generateEmptyTable()
    #
    #     # altitude
    #     self.dsbox_altitude.setValue(200.0)
    #
    #     # location in textbox
    #     if self.tbox_oper_location.text() != '':
    #         self.tbox_oper_location.setText('')
    #         # self.create_map() will be triggered by the event of textChange
    #     else:
    #         self.create_map_thread() # self.create_map()
    #
    #     # risk value
    #     self.label_fatal_max.setText(QTtranslate('Ground Fatality Rate (Maximum)'))
    #     self.tBox_risk_value_max.setText('')
    #     self.tBox_risk_value_avg.setText('')

    # def fn_plot(self):
    #     self.getDataFromQTable()
    #     self.create_map_thread()
    #     self.create_map_thread() # self.create_map()

    # def fn_import_wp(self):
    #     filename = fileDialog(fileExtension='csv')
    #     if filename is not None and filename != '':
    #         data_from_file = pd.read_csv(filename)
    #         self.write2table(data_from_file)

    # def fn_export_wp(self):
    #     filename = fileDialog(openfile=False, fileExtension='csv')
    #     if filename is not None and filename != '':
    #         self.getDataFromQTable()
    #         # TODO remove empty entries?
    #         self.data_from_user['waypoints'].to_csv(filename, index=False)

    # def fn_impt_oper_area(self):
    #     filename = fileDialog(fileExtension='csv')
    #     if filename is not None and filename != '':
    #         # read the file
    #         # TODO multiple regions?
    #         if filename[-4:] == '.csv':
    #             data_from_file = pd.read_csv(filename)
    #             coordinates = []
    #             for i, row in data_from_file.iterrows():
    #                 coordinates.append((row[1], row[0]))
    #             geometry = Polygon(coordinates)
    #
    #             df = pd.DataFrame({'geometry': [geometry]}) # TODO waypoint order is very important to shape
    #             self.data_from_user['operational_area'] = gpd.GeoDataFrame(df, geometry='geometry')
    #             self.create_map_thread() # self.create_map()
    #         else:
    #             msg = qtw.QMessageBox()
    #             msg.setIcon(qtw.QMessageBox.Critical)
    #             msg.setText(QTtranslate('Please input a csv file'))
    #             msg.setWindowTitle('Import Operational Area Error')
    #             msg.setStandardButtons(qtw.QMessageBox.Ok)
    #             msg.exec_()

    # def fn_input_location(self):
    #     text = self.tbox_oper_location.text()
    #     if text == '':
    #         self.input_area_bound = []
    #         self.create_map_thread() # self.create_map()
    #         self.completer_location.setCompletionPrefix('')
    #     elif text in self.subzone_list:
    #         bd = self.subzone_bounds.loc[self.subzone_bounds['SUBZONE_N'] == text.upper()]['geometry'].tolist()[0]
    #         self.input_area_bound = [ [bd[1], bd[0]], [bd[3], bd[2]] ]
    #         self.create_map_thread() # self.create_map()

    # def fn_oper_timeChanged(self):
    #     if self.timeChanged_trigger:
    #         self.create_map_thread() # self.create_map()

    # def fn_menu_import(self):
    #     filename = fileDialog(fileExtension='json')
    #     if filename is not None and filename != '':
    #         with open(filename) as fin:
    #             data_string = json.load(fin)
    #             data = json.loads(data_string)
    #         # assign data to widgets
    #         if 'UA_Type' in data.keys():
    #             dict_UA_Type = data['UA_Type']
    #             self.cbox_ua_brand.setCurrentIndex(0)
    #             self.fn_ua_brand_selected(0)
    #             if 'UA_Brand' not in dict_UA_Type.keys() or '' == dict_UA_Type['UA_Brand']:
    #                 pass
    #             else:
    #                 index = self.cbox_ua_brand.findText(dict_UA_Type['UA_Brand'])
    #                 if index == -1:
    #                     msg = qtw.QMessageBox()
    #                     msg.setIcon(qtw.QMessageBox.Critical)
    #                     msg.setText(QTtranslate('No item for UA Brand {}'.format(dict_UA_Type['UA_Brand'])))
    #                     msg.setWindowTitle('Import Data Error')
    #                     msg.setStandardButtons(qtw.QMessageBox.Ok)
    #                     msg.exec_()
    #                 else:
    #                     self.cbox_ua_brand.setCurrentIndex(index)
    #                     self.fn_ua_brand_selected(index)
    #                     if 'UA_Model' not in dict_UA_Type.keys() or '' == dict_UA_Type['UA_Model']:
    #                         pass
    #                     else:
    #                         index = self.cbox_ua_model.findText(dict_UA_Type['UA_Model'])
    #                         if index == -1:
    #                             msg = qtw.QMessageBox()
    #                             msg.setIcon(qtw.QMessageBox.Critical)
    #                             msg.setText(QTtranslate('No item for UA Model {}'.format(dict_UA_Type['UA_Model'])))
    #                             msg.setWindowTitle('Import Data Error')
    #                             msg.setStandardButtons(qtw.QMessageBox.Ok)
    #                             msg.exec_()
    #                         else:
    #                             self.cbox_ua_model.setCurrentIndex(index)
    #                             self.fn_ua_model_selected(index)
    #             # UA_Reg_No
    #
    #         dict_Operation_Information = data['Operation_Information']
    #         self.qde_oper_date.setDate(qtc.QDate(*dict_Operation_Information['Date']))
    #         self.timeChanged_trigger = False
    #         hour, minute, second = dict_Operation_Information['Time']
    #         self.sbox_oper_hour.setValue(int(hour))
    #         self.sbox_oper_minute.setValue(int(minute))
    #         self.timeChanged_trigger = True
    #         if 'Location' in dict_Operation_Information.keys():
    #             self.tbox_oper_location.setText(QTtranslate(dict_Operation_Information['Location']))
    #         if 'Operational_Area' in dict_Operation_Information.keys():
    #             oper_area_string = dict_Operation_Information['Operational_Area']
    #             json_dict = json.loads(oper_area_string)
    #             if 'features' in json_dict.keys():
    #                 self.data_from_user['operational_area'] = gpd.GeoDataFrame.from_features(json_dict['features'])
    #             else:
    #                 self.data_from_user['operational_area'] = gpd.GeoDataFrame([])
    #         else:
    #             self.data_from_user['operational_area'] = gpd.GeoDataFrame([])
    #
    #         dict_Altitude_Information = data['Altitude_Information']
    #         self.dsbox_altitude.setValue(dict_Altitude_Information['Altitude'])
    #
    #         dict_Waypoints = data['Waypoints']
    #         wp_str = dict_Waypoints['Waypoints']
    #         self.write2table(pd.read_json(wp_str))
    #         self.getDataFromQTable()
    #
    #         # dict_Time_Of_Operation = data['Time_Of_Operation']
    #         # self.time_slider.setValue(dict_Time_Of_Operation['Time'])
    #         if self.tBox_risk_value_max.text() or self.tBox_risk_value_avg.text():
    #             self.lambda_fat()
    #
    #         self.create_map_thread() # self.create_map()

    # def fn_menu_export(self):
    #     filename = fileDialog(openfile=False, fileExtension='json')
    #     if filename is not None and filename != '':
    #         data = {}
    #         # add data
    #         dict_UA_Type = {}
    #         if self.cbox_ua_brand.currentIndex() == 0:
    #             dict_UA_Type['UA_Brand'] = ''
    #             dict_UA_Type['UA_Model'] = ''
    #         else:
    #             dict_UA_Type['UA_Brand'] = self.cbox_ua_brand.currentText()
    #             dict_UA_Type['UA_Model'] = self.cbox_ua_model.currentText()
    #         dict_UA_Type['UA_Reg_No'] = self.cbox_ua_reg.currentText()
    #         data['UA_Type'] = dict_UA_Type
    #
    #         dict_Operation_Information = {}
    #         dict_Operation_Information['Date'] = self.qde_oper_date.date().getDate()
    #         # self.qde_oper_date.setDate(qtc.QDate(*(2022,8,23)))
    #         # qtime = self.oper_time.time() # upgraded UI
    #         # dict_Operation_Information['Time'] = (qtime.hour(), qtime.minute(), qtime.second()) # upgraded UI
    #         hour = self.sbox_oper_hour.value()
    #         minute = self.sbox_oper_minute.value()
    #         dict_Operation_Information['Time'] = (hour, minute, 0)
    #         # self.oper_time.setTime(qtc.QTime(*(12, 15, 10)))
    #         dict_Operation_Information['Location'] = self.tbox_oper_location.text()
    #         if not self.data_from_user['operational_area'].empty:
    #             dict_Operation_Information['Operational_Area'] = self.data_from_user['operational_area'].to_json()
    #         data['Operation_Information'] = dict_Operation_Information
    #
    #         dict_Altitude_Information = {}
    #         dict_Altitude_Information['Altitude'] = self.dsbox_altitude.value()
    #         data['Altitude_Information'] = dict_Altitude_Information
    #
    #         dict_Waypoints = {}
    #         self.getDataFromQTable()
    #         dict_Waypoints['Waypoints'] = self.data_from_user['waypoints'].to_json()
    #         data['Waypoints'] = dict_Waypoints
    #
    #         data_string = json.dumps(data)
    #         with open(filename, 'w') as fout:
    #             json.dump(data_string, fout)

    def fn_save(self):
        pass


    # def fn_click_on_map(self):
    #     self.listener_btn_add_wp_click = not self.listener_btn_add_wp_click
    #     if self.listener_btn_add_wp_click:
    #         self.btn_click_on_map.setStyleSheet(color_background3)
    #     else:
    #         self.btn_click_on_map.setStyleSheet(color_background1)

    def generateEmptyTable(self, numRows=0):
        self.tab_waypoints.setColumnCount(len(self.table_columns))
        self.tab_waypoints.setHorizontalHeaderLabels(self.table_columns)
        self.tab_waypoints.setRowCount(numRows)
        for i in range(numRows):
            for j in range(len(self.table_columns)):
                self.tab_waypoints.setItem(i, j, qtw.QTableWidgetItem())
        if numRows >= 1:
            self.tab_waypoints.setItem(0, 3, qtw.QTableWidgetItem('Take-off'))
        if numRows >= 2:
            self.tab_waypoints.setItem(1, 3, qtw.QTableWidgetItem('Landing'))

    def write2table(self, data):
        # TODO data validity check
        numRows, numCols = data.shape
        self.tab_waypoints.setRowCount(numRows)
        data.reset_index()
        if numCols < 4:
            list_remarks = ['Take-off'] + ['Waypoint'] * (numRows-2) + ['Landing']
            data['Remarks'] = list_remarks
            numCols += 1
        for i, row in data.iterrows():
            for j, col_name in enumerate(self.table_columns):
                if col_name not in row.index or row[col_name] is None or (isinstance(row[col_name], float) and np.isnan(row[col_name])):
                    self.tab_waypoints.setItem(i, j, qtw.QTableWidgetItem())
                else:
                    if j < 2: # lat, lon
                        self.tab_waypoints.setItem(i, j, qtw.QTableWidgetItem("{:.6f}".format(row[col_name])))
                    elif j == 2: # alt
                        self.tab_waypoints.setItem(i, j, qtw.QTableWidgetItem("{:.1f}".format(row[col_name])))
                    else: # remarks
                        self.tab_waypoints.setItem(i, j, qtw.QTableWidgetItem(row[col_name]))
        self.tab_waypoints.update()
        # self.tab_waypoints.setItem(0,0, qtw.QTableWidgetItem('1'))
        # self.tab_waypoints.setItem(0,1, qtw.QTableWidgetItem('2'))

    def getDataFromQTable(self):
        rowCount = self.tab_waypoints.rowCount()
        columnCount = self.tab_waypoints.columnCount()
        waypoints = []
        for row in range(rowCount):
            tmp_row_entry = []
            for col in range(columnCount):
                if self.tab_waypoints.item(row, col).text() == '':
                    value = None
                else:
                    if col < 3:  # lat, lon, alt
                        try:
                            value = float(self.tab_waypoints.item(row, col).text())
                        except ValueError:
                            value = None
                    else: # remarks
                        value = self.tab_waypoints.item(row, col).text()
                tmp_row_entry.append(value)
            if not all(v is None for v in tmp_row_entry[:-1]):
                waypoints.append(tmp_row_entry)
        self.data_from_user['waypoints'] = pd.DataFrame(waypoints, columns=self.table_columns)


    def fn_ua_brand_selected(self, index):
        # Clear the UA Model comboBox
        self.cbox_ua_model.clear()
        # Dependent comboBoxes
        self.cbox_ua_model.addItem('Select UA Model...')
        # Disable first category item
        self.cbox_ua_model.model().item(0).setEnabled(False)
        if index != 0:
            for model in self.cbox_ua_brand.itemData(index).keys():
                reg_no = self.cbox_ua_brand.itemData(index)[model]
                self.cbox_ua_model.addItem(model, reg_no)
        self.cbox_ua_reg.clear()
        self.cbox_ua_reg.addItem('Select UA Model to Load Registration Number...')
        self.cbox_ua_reg.model().item(0).setEnabled(False)


    def fn_ua_model_selected(self, index):
        print('fn_ua_model_selected, index', index)
        self.cbox_ua_reg.clear()
        if len(self.cbox_ua_model.itemData(index)) > 0:
            self.cbox_ua_reg.addItem('Select UA Registration Number...')
        else:
            self.cbox_ua_reg.addItem('No Registration Numbers for This Model')
        self.cbox_ua_reg.model().item(0).setEnabled(False)
        if index != 0:
            self.cbox_ua_reg.addItems(self.cbox_ua_model.itemData(index))

        # features for risk map, not related to FYP
        # new_mass = drone_model2mass(self.df_UA_info, self.cbox_ua_brand.currentText(), self.cbox_ua_model.currentText())
        # print(self.cbox_ua_brand.currentText(), self.cbox_ua_model.currentText(), 'Mass = ', new_mass)
        # if self.flight_drone_mass != new_mass:
        #     self.flight_drone_mass = new_mass

            # useGroundFatRisk = self.cbox_ua_brand.currentText() != 'Other'
            # self.generate_risk_tier_data(useGroundFatRisk=useGroundFatRisk)
            # self.create_map_thread() # self.create_map()

    @qtc.pyqtSlot()
    def _update_today(self):
        self._today_button.clearFocus()
        today = qtc.QDate.currentDate()
        self.qde_oper_date.calendarWidget().setSelectedDate(today)

    # calculate lambda fatality, not related to FYP
    # def lambda_fat(self):
    #     if self.flight_drone_mass == -1:
    #         msg = qtw.QMessageBox()
    #         msg.setIcon(qtw.QMessageBox.Critical)
    #         msg.setText(QTtranslate('Please Select the UA Brand and Model'))
    #         msg.setWindowTitle('Risk Evaluation Error')
    #         msg.setStandardButtons(qtw.QMessageBox.Ok)
    #         msg.setStyleSheet(
    #             "QLabel{height: 150px; min-height: 150px; max-height: 150px; width: 150px; min-width: 150px; max-width: 150px}")
    #         msg.exec_()
    #     else:
    #         # list of subzones
    #         dict_subzone_count = {}
    #         if self.tbox_oper_location.text():
    #             dict_subzone_count[self.tbox_oper_location.text()] = 0 # giving weight of zero as only waypoints contribute to the avg fatality
    #             if not self.data_from_user['waypoints'].empty:
    #                 gdf_geometry = gpd.GeoDataFrame(self.gdf_riskTier['geometry'])
    #                 for row in self.data_from_user['waypoints'].iterrows():
    #                     wp = Point(row[1].iloc[1], row[1].iloc[0])
    #                     index = gdf_geometry.contains(wp)
    #                     if index.any():
    #                         zone_name = self.gdf_riskTier[index]['SUBZONE_N'].values[0].title()
    #                         if zone_name in dict_subzone_count.keys():
    #                             dict_subzone_count[zone_name] += 1
    #                         else:
    #                             dict_subzone_count[zone_name] = 1
    #
    #         # calculate the lambda fatalities of the subzones
    #         if dict_subzone_count:
    #             fatalities = []
    #             weights = []
    #             if self.cbox_ua_brand.currentText() != 'Other':
    #                 self.label_fatal_max.setText(QTtranslate('Ground Fatality Rate (Maximum)'))
    #                 for subzone_location in dict_subzone_count.keys():
    #                     risk_value = calculate_risk(subzone_location, self.cbox_ua_brand.currentText(),
    #                                                 self.cbox_ua_model.currentText(), int(self.sbox_oper_hour.text()))
    #                     fatalities.append(risk_value)
    #                     weights.append(dict_subzone_count[subzone_location])
    #             else:
    #                 self.label_fatal_max.setText(QTtranslate('UA Failure Rate Threshold (Maximum)'))
    #                 self.label_fatal_avg.setText(QTtranslate('UA Failure Rate Threshold (Average)'))
    #                 for subzone_location in dict_subzone_count.keys():
    #                     risk_value = calculate_risk_others_old(subzone_location, int(self.sbox_oper_hour.text()))
    #                     fatalities.append(risk_value)
    #                     weights.append(dict_subzone_count[subzone_location])
    #             fatalities = np.array(fatalities)
    #             risk_value_max = np.max(fatalities)
    #             if weights == [0]: # only subzone name given, no waypoints
    #                 weights = [1]
    #             risk_value_avg = np.average(fatalities, weights=weights)
    #             self.tBox_risk_value_max.setText(QTtranslate(sci_notation(risk_value_max)))
    #             self.tBox_risk_value_avg.setText(QTtranslate(sci_notation(risk_value_avg)))
    #             msg = qtw.QMessageBox()
    #             msg.setIcon(qtw.QMessageBox.NoIcon)
    #             print('[Debug]risk_value_max = {:.3f}'.format(risk_value_max))
    #             if risk_value_max < 1e-3: # TODO it should be related to the drone
    #                 title_str = 'Safe'
    #                 msg_str = 'Your drone operation is safe.\nYou may proceed to the next step.'
    #                 style_str = "QLabel{height: 75px; min-height: 75px; width: 200px; min-width: 150px;}"
    #             else:
    #                 title_str = 'Not Safe'
    #                 msg_str = 'The reliability of the drone is BELOW the requirement of the selected subzone!\nChange another location or select a smaller drone size.'
    #                 style_str = "QLabel{height: 75px; min-height: 75px; width: 420px; min-width: 150px;}"
    #             msg.setWindowTitle(QTtranslate(title_str))
    #             msg.setText(QTtranslate(msg_str))
    #             msg.setStandardButtons(qtw.QMessageBox.Ok)
    #             msg.setStyleSheet(style_str) #  max-height: 150px; max-width: 150px
    #             msg.exec_()
    #         else:
    #             msg = qtw.QMessageBox()
    #             msg.setIcon(qtw.QMessageBox.Critical)
    #             msg.setText(QTtranslate('Please Select Location'))
    #             msg.setWindowTitle('Risk Evaluation Error')
    #             msg.setStandardButtons(qtw.QMessageBox.Ok)
    #             msg.setStyleSheet(
    #                 "QLabel{height: 150px; min-height: 150px; max-height: 150px; width: 150px; min-width: 150px; max-width: 150px}")
    #             msg.exec_()

    def handle_downloadRequested(self, item):
        path, _ = qtw.QFileDialog.getSaveFileName(
            self, "Save File", item.suggestedFileName()
        )
        if path:
            item.setPath(path)
            item.accept()


    def handle_downloadRequested(self, item):
        path, _ = qtw.QFileDialog.getSaveFileName(
            self, "Save File", item.suggestedFileName()
        )
        if path:
            item.setPath(path)
            item.accept()

    def closeEvent(self, event):
        pass

def fileDialog(openfile=True, fileExtension=''):
    dialog = qtw.QFileDialog()

    options = qtw.QFileDialog.Options()
    options |= qtw.QFileDialog.DontUseNativeDialog

    fileExtension = fileExtension.lower()
    nameFiler = ''
    suffix = ''
    if 'csv' in fileExtension:
        nameFiler = nameFiler + 'CSV files (*.csv);;'
        suffix = 'csv'
    if 'json' in fileExtension:
        nameFiler = nameFiler + 'JSON files (*.json);;'
        suffix = 'json'
    nameFiler = nameFiler + 'All Files (*)'
    dialog.setNameFilter(nameFiler)

    if openfile:
        dialog.setAcceptMode(qtw.QFileDialog.AcceptOpen)
        if dialog.exec() == qtw.QDialog.Accepted:
            fileName = dialog.selectedFiles()[0]
        else:
            fileName = None
    else:
        dialog.setDefaultSuffix(suffix)
        dialog.setAcceptMode(qtw.QFileDialog.AcceptSave)
        if dialog.exec() == qtw.QDialog.Accepted:
            fileName = dialog.selectedFiles()[0]
        else:
            fileName = None
    return fileName

class WebEnginePage(QtWebEngineWidgets.QWebEnginePage):
    def __init__(self, parent):
        super().__init__(parent)
        # parent is the object that having the function handleConsoleMessage_waypoint, not nessarily be the parent of it
        self.parent = parent

    def javaScriptConsoleMessage(self, level, msg, line, sourceID):
        print(msg)  # TODO　Debug Check js errors
        if 'coordinates' in msg:
            self.parent.handleConsoleMessage_waypoint(msg)
        elif 'time' in msg:
            self.parent.handleConsoleMessage_timeSlider(msg)

class QLineEdit_TPR(qtw.QLineEdit):
    def mousePressEvent(self, event):
        if (event.button() == qtc.Qt.LeftButton):
            self.completer().complete()
        super().mousePressEvent(event)


if __name__ == '__main__':
    app = qtw.QApplication(sys.argv)
    app.setStyle('Fusion')
    #app.setStyleSheet(qdarkstyle.load_stylesheet(pyside=False))
    VLOSWindow = qtw.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(VLOSWindow)
    VLOSWindow.show()
    sys.exit(app.exec_())