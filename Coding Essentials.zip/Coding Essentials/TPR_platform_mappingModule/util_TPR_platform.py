import numpy as np
import os
import pandas as pd
import geopandas as gpd
from shapely.ops import unary_union
import time

cols_time = ['{:.1f}'.format(v) for v in range(4, 25)]

def sci_notation(number, sig_fig=2):
    ret_string = "{0:.{1:d}e}".format(number, sig_fig)
    a, b = ret_string.split("e")
    # remove leading "+" and strip leading zeros
    b = int(b)
    return a + " x 10 ^ " + str(b)

def in_range(waypoint):
    # value validity check
    # if np.isnan(waypoint).sum() > 0:
    if waypoint.iloc[:3].isna().any():
        return False
    if (waypoint.iloc[:3] < 0).any():
        return False
    # TODO check whether within region
    return True

def TPR_filepath(path):
    if os.getcwd()[-4:] == 'dist':
        return os.path.join(os.path.dirname(os.getcwd()), path)
    else:
        return path

def meter2feet(height_meter):
    return 3.2808 * height_meter

def feet2meter(height_feet):
    return 0.3048 * height_feet

def angle2distance(angle):
    angle * 6.371e6 * np.pi / 180

def distance2angle(distance):
    return distance / 6.371e6 * 180 / np.pi


def data_UA_type(df_UA_info):
    dict_ua_type_info = {}
    UA_brand_names = df_UA_info['UA Brand'].drop_duplicates().tolist()

    if 'Other' in UA_brand_names:
        # move 'Others' to the last
        UA_brand_names.remove('Other')
        UA_brand_names.append('Other')

    for brand in UA_brand_names:
        df_single_brand = df_UA_info.loc[df_UA_info['UA Brand'] == brand]
        models_of_the_brand = df_single_brand['UA Model'].drop_duplicates().tolist()
        dict_model_regNo = {}
        for model in models_of_the_brand:
            regNo_of_the_model = df_single_brand['CAAS Number'].loc[df_single_brand['UA Model'] == model].drop_duplicates().tolist()
            if '-' in regNo_of_the_model: # and len(regNo_of_the_model) > 1:
                regNo_of_the_model.remove('-')
            dict_model_regNo[model] = regNo_of_the_model
        dict_ua_type_info[brand] = dict_model_regNo

    return dict_ua_type_info



def drone_model2mass(df_UA_info, brand, model):
    index_brand = df_UA_info['UA Brand'] == brand
    index_model = df_UA_info['UA Model'] == model
    mass = df_UA_info[index_brand & index_model]['Weight'].drop_duplicates().to_list()
    assert len(mass) == 1, 'found {} value for UA weight, {}'.format(len(mass), mass)
    return mass[0]

def compute_choropleth_styledict(gdf_riskTier):
    colorCode = {'Low': '#008000',
                 'Med': '#FFFF00',
                 'High': '#FF0000',
                 'SP': '#000000'}
    opacity = 0.3
    df_style = pd.DataFrame(gdf_riskTier[cols_time], columns=cols_time) # suppress the warning
    for i in range(3):
        df_style.insert(i, '{:.1f}'.format(i), df_style['4.0'])

    new_col_names = range(24)
    dict_col_rename = {old: new for old, new in zip(df_style.columns, new_col_names)}
    df_style.rename(columns=dict_col_rename, inplace=True)
    for tier in colorCode:
        color = colorCode[tier]
        df_style.replace(tier, color, inplace=True)

    styledata = {}

    for i in gdf_riskTier.index:
        df_i = pd.DataFrame(df_style.iloc[i].to_list(), columns=['color'], index=df_style.columns)
        df_i.insert(1, 'opacity', opacity)
        styledata[i] = df_i

    styledict = {
        str(subzone): data.to_dict(orient="index") for subzone, data in styledata.items()
    }
    return styledict

def data_compacting(gdf):
    df_pattern = gdf[cols_time].drop_duplicates()
    list_compact = []
    for pattern in df_pattern.iterrows():
        gdf_tmp = gdf
        for col in cols_time:
            gdf_tmp = gdf_tmp[gdf_tmp[col] == pattern[1][col]]
        if len(gdf_tmp) > 1:
            list_compact.append(pattern[1].to_list() + [unary_union(gdf_tmp['geometry'].to_list())])
        else:
            list_compact.append(pattern[1].to_list() + gdf_tmp['geometry'].to_list())
    gdf_compact = gpd.GeoDataFrame(list_compact, columns=cols_time + ['geometry'])
    gdf_compact.crs = gdf.crs
    return gdf_compact

class TicToc:
    def __init__(self):
        self._time_start = None
    
    def tic(self):
        self._time_start = time.time()
    
    def toc(self):
        if self._time_start is None:
            print('Error in class tictoc, toc() is called before tic()')
            return None
        else:
            duration = time.time() - self._time_start
            self._time_start = None
            return duration
    # brand_str = brand.replace(' ', '').lower()
    # model_str = model.replace(' ', '').lower()
    # if brand_str == 'dji':
    #     if model_str == 'flamewheelf450':
    #         pass
    #     elif model_str == 'inspire1':
    #         return 2.85
    #     elif model_str == 'm600pro':
    #         return 15.5
    #     elif model_str == 'mavic2zoom':
    #         pass
    #     elif model_str == 'mavicair':
    #         pass
    #     elif model_str == 'mavicproplatinum':
    #         return 0.74
    #     elif model_str == 's900':
    #         return 3.3
    # elif brand_str == 'saga':
    #     if model_str == 'e450pro':
    #         pass
    # elif brand_str == 'tarot':
    #     if model_str == 'ironman650':
    #         pass # TODO
    #     elif model_str == 'x8':
    #         pass
    # elif brand_str == 'other':
    #     if model_str == '100kgdemodrone':
    #         return 100
    #     elif model_str == '1.5kgdemodrone':
    #         return 1.5
    # return -1

# def drone_mass_tiers(mass):
#     if mass <= 1:
#         return 0
#     elif mass <= 10:
#         return 1
#     elif mass <= 100:
#         return 2
#     elif mass <= 1000:
#         return 3